package com.cft.shift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiftApplicationTests {

	@Test
	void contextLoads() {
	}

}
